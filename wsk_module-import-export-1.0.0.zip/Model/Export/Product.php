<?php
/**
 * Copyright © 2017 Kevwis. All rights reserved.
 */
namespace Wsk\ImportExport\Model\Export;


class Product extends \Magento\CatalogImportExport\Model\Export\Product
{

}
