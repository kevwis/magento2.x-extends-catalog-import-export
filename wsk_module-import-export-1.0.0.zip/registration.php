<?php
/**
 * Copyright © 2017 Kevwis. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Wsk_ImportExport',
    __DIR__
);
