<?php
/**
 * Copyright © 2017 Kevwis. All rights reserved.
 */
namespace Wsk\ImportExport\Model\Import;



class Product extends \Magento\CatalogImportExport\Model\Import\Product
{

}
